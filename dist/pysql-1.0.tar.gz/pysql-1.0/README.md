# pysql
MYSQL Database package to run database transactions. Can work with both mysqlclient, pymysql and msqlconnector
# Required Packages
- Any Mysql Client package
- decouple
# Optional Package
- Django
# Configuration
- Use the .enve.example template for your database configurations
